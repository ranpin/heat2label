import os
os.environ['CUDA_VISIBLE_DEVICES'] = '6'
from PIL import Image
import cv2
import numpy as np
import random
import json
from copy import deepcopy

from matplotlib import pyplot as plt
import torch

from daam import trace, set_seed
from diffusers import StableDiffusionPipeline, StableDiffusionImg2ImgPipeline

def text2img(prompt="", seed=41):
    """
    prompt -> str: a description
    seed -> int: random seed to reproduce
    
    """


    pipe = StableDiffusionPipeline.from_pretrained('CompVis/stable-diffusion-v1-4')
    pipe = pipe.to('cuda')

    gen = set_seed(seed)

    with torch.cuda.amp.autocast(dtype=torch.float16), torch.no_grad():
        with trace(pipe) as tc:
            out = pipe(prompt, num_inference_steps=30, generator=gen)
            heat_map = tc.compute_global_heat_map()
            heat_map = heat_map.compute_word_heat_map('cars')
            heat_map.plot_overlay(out.images[0])


def img2img(prompt="", keyword="", img_path_file="", num_outputs=1, save_dir="output/attentions"):
    """
    prompt -> str: a description
    keyword -> str: a focused word to show heat map
    img_path -> str: a path to image
    seed -> int: random seed to reproduce default 
    
    """

    pipe = StableDiffusionImg2ImgPipeline.from_pretrained('CompVis/stable-diffusion-v1-4')
    pipe = pipe.to('cuda')

    img_path_list = []
    with open(img_path_file, "r") as f:
        for line in f:
            line = line.strip()
            img_path_list.append(line)


    for img_path in img_path_list:
        print("=================")
        print(img_path)
        print("=================")
        random_seeds = random.sample(range(10000), num_outputs)    

        image = cv2.imread(img_path)
        # image = Image.open(img_path).convert("RGB")
        image_name = img_path.split("/")[-1].split(".png")[0]
        
        # To write mask
        if "camera5" in image_name:
            new_image, mask_keep = with_mask(image, "camera5")
        elif "camera4" in image_name:
            new_image, mask_keep = with_mask(image, "camera4")
        
        # image_mask_keep = cv2.bitwise_and(image, mask_keep)
        image_mask_keep = cv2.add(image, np.zeros(np.shape(image), dtype=np.uint8), mask=mask_keep)
        # cv2.imwrite("./xxxx.png", image_mask_keep)
        # exit()

        image = Image.fromarray(new_image)

        image_h, image_w = image.height, image.width
        # image = image.resize((512, int(image_h * 512. / image_w)))
        # image = image.resize((768, int(image_h * 768. / image_w)))
        image = image.resize((768, 768))

        # xxx = int(image_h * 768. / image_w)
        # image = image.resize((512, 512))

        with torch.cuda.amp.autocast(dtype=torch.float16), torch.no_grad():

            for seed in random_seeds:

                save_path = os.path.join(save_dir, image_name, str(seed))
        
                if not os.path.exists(save_path):
                    os.makedirs(save_path)

                gen = set_seed(seed)
                with trace(pipe) as tc:
                    out = pipe(
                        prompt=prompt, 
                        init_image=image,
                        strength=0.45, 
                        # strength=0.4, 
                        guidance_scale=7.5,
                        # num_inference_steps=30, 
                        generator=gen,
                    )
                    heat_map = tc.compute_global_heat_map()
                    heat_map = heat_map.compute_word_heat_map(keyword)
                    out_img, out_heat, out_bbox = heat_map.plot_overlay(out.images[0], src_size=(image_w, image_h))

                    out_img = cv2.addWeighted(out_img, 1, image_mask_keep, 1, 0)

                    # ================================================================
                    out_heat = cv2.applyColorMap(np.uint8(255 * out_heat), cv2.COLORMAP_JET)
                    # out_img = cv2.cvtColor(out_img, cv2.COLOR_BGR2RGB)
                    
                    out_img_showbox = deepcopy(out_img)

                    out_valid_bbox = []

                    for bbox in out_bbox:
                        if bbox[1] >= image_h - 200: # y1
                            continue
                        bbox = [int(_) for _ in bbox]
                        out_valid_bbox.append(bbox)
                        cv2.rectangle(
                            out_img_showbox, 
                            (bbox[0], bbox[1]), # x1, y1
                            (bbox[2], bbox[3]), # x2, y2
                            (0, 255, 255),
                            4,
                            # -1,
                        )

                    cv2.imwrite("{}/img.png".format(save_path, seed), out_img)
                    cv2.imwrite("{}/heat.png".format(save_path, seed), out_heat)
                    cv2.imwrite("{}/box.png".format(save_path, seed), out_img_showbox)

                    with open("{}/label.json".format(save_path, seed), "w") as f:
                        f.write(json.dumps({keyword: out_valid_bbox}))


def with_mask(img, position):
    front_node = [
        [0,1079], [0,1044], [254,978], [365,965],
        [462,943], [679,796], [691,780], [721,760], [756,761], [846,736], [949,731],
        [948,714], [929,704], [949,693],
        [961,692], [980,701], [961,717], [960,732],
        [1036,732], [1150,762], [1185,766],
        [1234,801], [1428,937], [1768,1009], [1919,1046],
        [1919,1079]
    ]
    back_node = [
        [0,1079], [0,1042], [115,1021], [342,985], [563,958],
        [811,944], [965,941], [1178,944], [1425,963],[1662,997],
        [1919,1042],[1919,1079]
    ]
    shadow = img.copy()
    keep = np.zeros(img.shape, dtype=np.uint8)
    keep = cv2.cvtColor(keep, cv2.COLOR_RGB2GRAY)

    # 前置相机掩码
    if position == "camera5":
        front_node = np.array(front_node)
        cv2.fillConvexPoly(shadow, front_node, 0)
        cv2.fillConvexPoly(keep, front_node, 255)
        img = cv2.bitwise_and(img, shadow)
    # 后置相机掩码
    elif position == "camera4":
        back_node = np.array(back_node)
        cv2.fillConvexPoly(shadow, back_node, 0)
        cv2.fillConvexPoly(keep, back_node, 255)
        img = cv2.bitwise_and(img, shadow)

    return img, keep
            

if __name__ == "__main__":

    # text2img("")

    img2img(
        prompt="motorcyclist on road",
        keyword="motorcyclist",
        # prompt="tricycle rider on road",
        # keyword="tricycle",
        # img_path="318imgs/road_and_cows.png",
        img_path_file="/home/zhaiyupeng/agv/ImageGeneration/daam/318imgs/motorcyclist.txt",
        num_outputs=20,
        save_dir="output_new/attentions/motorcyclist",
    )

    # img2img(
    #     prompt="truck on road",
    #     keyword="truck",
    #     # prompt="tricycle rider on road",
    #     # keyword="tricycle",
    #     # img_path="318imgs/road_and_cows.png",
    #     img_path_file="/home/zhaiyupeng/agv/ImageGeneration/daam/318imgs/truck.txt",
    #     num_outputs=20,
    #     save_dir="output_new/attentions/truck",
    # )